package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.List;

public class ParabankLoginTest {
    WebDriver driver;
    WebDriverWait wait;
    String baseURL = "https://parabank.parasoft.com/parabank/index.htm";

    @BeforeTest
    public void openBrowser() {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get(baseURL);

        // انتظر الصفحة تفتح كويس
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        System.out.println("✅ Page title: " + driver.getTitle());

        // check iframes
        List<WebElement> frames = driver.findElements(By.tagName("iframe"));
        System.out.println("🔍 Number of iframes: " + frames.size());

        if (frames.size() > 0) {
            // جرب ندخل على أول iframe لو موجود
            driver.switchTo().frame(frames.get(0));
            System.out.println("➡️ Switched to iframe");
        }
    }

    @Test(priority = 1)
    public void testLoginPositiveScenario() {
        try {
            // Step 1: Find login fields
            WebElement usernameTxt = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
            WebElement passwordTxt = driver.findElement(By.name("password"));
            WebElement loginBtn = driver.findElement(By.xpath("//input[@value='Log In']"));

            usernameTxt.sendKeys("john");
            passwordTxt.sendKeys("demo");
            loginBtn.click();

            // Step 2: Switch back to main page if needed
            driver.switchTo().defaultContent();

            // Step 3: Confirm login success
            WebElement accountOverview = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//h1[contains(text(),'Accounts Overview')]")));

            Assert.assertTrue(accountOverview.isDisplayed(), "❌ Login failed.");
            System.out.println("✅ Login successful – Accounts Overview is visible.");
        } catch (Exception e) {
            System.out.println("❌ Exception: " + e.getMessage());
            System.out.println("📄 Page Source:\n" + driver.getPageSource());
            Assert.fail("Test failed due to exception.");
        }
    }

    @AfterTest
    public void closeBrowser() {
        driver.quit();
        System.out.println("🛑 Browser closed.");
    }
}

