package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.List;

public class AccountOverviewTest {
    WebDriver driver;
    WebDriverWait wait;
    String baseURL = "https://parabank.parasoft.com/parabank/index.htm";

    @BeforeTest
    public void openBrowser() {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get(baseURL);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @Test
    public void testAccountOverview() {
        try {
            // Login
            WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
            WebElement password = driver.findElement(By.name("password"));
            WebElement loginBtn = driver.findElement(By.xpath("//input[@value='Log In']"));

            username.sendKeys("john");
            password.sendKeys("demo");
            loginBtn.click();

            // Accounts Overview page
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Accounts Overview')]")));
            System.out.println("✅ Logged in and overview page loaded.");

            // Get account links
            List<WebElement> accountLinks = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                    By.xpath("//a[contains(@href, 'activity.htm')]")));

            if (accountLinks.isEmpty()) {
                System.out.println("❌ No accounts found.");
                Assert.fail("No accounts to test.");
            }

            // Open first account
            WebElement firstAccount = accountLinks.get(0);
            String accountText = firstAccount.getText();
            firstAccount.click();
            System.out.println("➡️ Opened account: " + accountText);

            // Account details
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Account Details')]")));
            System.out.println("✅ Account details page loaded.");

            // Get balance using ID
            WebElement balance = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("availableBalance")));
            System.out.println("💰 Available Balance: " + balance.getText());

        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
            Assert.fail("Test failed due to exception.");
        }
    }

    @AfterTest
    public void closeBrowser() {
        driver.quit();
        System.out.println("🛑 Browser closed.");
    }
}





