package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class RequestLoanTest {
    WebDriver driver;
    WebDriverWait wait;
    String baseURL = "https://parabank.parasoft.com/parabank/index.htm";

    @BeforeTest
    public void openBrowser() {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get(baseURL);
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @Test
    public void testRequestLoan() {
        try {
            // Step 1: Login
            WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
            WebElement password = driver.findElement(By.name("password"));
            WebElement loginBtn = driver.findElement(By.xpath("//input[@value='Log In']"));

            username.sendKeys("john");
            password.sendKeys("demo");
            loginBtn.click();

            // Step 2: Navigate to "Request Loan"
            WebElement requestLoanLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Request Loan")));
            requestLoanLink.click();

            // Instead of relying on title, wait for the amount field to appear
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("amount")));
            System.out.println("✅ Request Loan page loaded.");

            // Step 3: Fill loan form
            driver.findElement(By.id("amount")).sendKeys("1000");
            driver.findElement(By.id("downPayment")).sendKeys("100");

            Select fromAccount = new Select(driver.findElement(By.id("fromAccountId")));
            fromAccount.selectByIndex(0);

            driver.findElement(By.xpath("//input[@value='Apply Now']")).click();

            // Step 4: Verify result
            WebElement resultHeader = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//h1[contains(text(),'Loan Request Processed')]")));
            Assert.assertTrue(resultHeader.isDisplayed(), "❌ Loan request failed.");
            System.out.println("✅ Loan request submitted successfully.");

        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
            Assert.fail("Test failed due to exception.");
        }
    }

    @AfterTest
    public void closeBrowser() {
        driver.quit();
        System.out.println("🛑 Browser closed.");
    }
}


