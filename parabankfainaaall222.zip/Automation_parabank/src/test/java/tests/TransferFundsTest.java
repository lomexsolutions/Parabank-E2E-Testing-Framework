package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.List;

public class TransferFundsTest {
    WebDriver driver;
    WebDriverWait wait;
    String baseURL = "https://parabank.parasoft.com/parabank/index.htm";

    @BeforeTest
    public void openBrowser() {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get(baseURL);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @Test
    public void testTransferFunds() {
        try {
            // Step 1: Login
            WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
            WebElement password = driver.findElement(By.name("password"));
            WebElement loginBtn = driver.findElement(By.xpath("//input[@value='Log In']"));

            username.sendKeys("john");
            password.sendKeys("demo");
            loginBtn.click();

            // Step 2: Confirm login success
            WebElement accountsOverview = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//h1[contains(text(), 'Accounts Overview')]")));
            Assert.assertTrue(accountsOverview.isDisplayed(), "Login failed.");
            System.out.println("Logged in and Accounts Overview page is visible.");

            // Step 3: Navigate to Transfer Funds
            WebElement transferFundsLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Transfer Funds")));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", transferFundsLink);
            transferFundsLink.click();
            System.out.println("Clicked on Transfer Funds link.");

            // Step 4: Confirm Transfer Funds page loaded
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//h1[contains(text(), 'Transfer Funds')]")));
            System.out.println("Transfer Funds page loaded.");

            // Step 5: Fill form
            WebElement amountField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("amount")));
            amountField.sendKeys("100");

            Select fromAccount = new Select(driver.findElement(By.id("fromAccountId")));
            Select toAccount = new Select(driver.findElement(By.id("toAccountId")));

            List<WebElement> options = fromAccount.getOptions();

            if (options.size() < 2) {
                Assert.fail("Not enough accounts to perform transfer.");
            }

            fromAccount.selectByIndex(0);
            toAccount.selectByIndex(1);

            System.out.println("Transferring from " + options.get(0).getText() + " to " + options.get(1).getText());

            // Step 6: Submit
            driver.findElement(By.xpath("//input[@value='Transfer']")).click();

            // Step 7: Verify success
            WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//h1[contains(text(), 'Transfer Complete')]")));
            Assert.assertTrue(successMessage.isDisplayed(), "Transfer not successful.");
            System.out.println("Transfer completed successfully.");

        } catch (TimeoutException e) {
            System.out.println("TimeoutException caught: " + e.getMessage());
            System.out.println("PAGE SOURCE:\n" + driver.getPageSource());
            throw e;
        }
    }

    @AfterTest
    public void closeBrowser() {
        driver.quit();
    }
}







