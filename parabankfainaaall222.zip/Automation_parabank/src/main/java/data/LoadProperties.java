package data;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class LoadProperties {
    public static Properties userData;

    static {
        try {
            String filePath = System.getProperty("user.dir") + "/src/main/java/data/UserData.properties";
            FileInputStream stream = new FileInputStream(filePath);
            userData = new Properties();
            userData.load(stream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
