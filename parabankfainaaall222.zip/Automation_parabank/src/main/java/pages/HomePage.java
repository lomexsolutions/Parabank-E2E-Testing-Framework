package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends PageBase {

    public HomePage(WebDriver driver) {
        super(driver);
    }

    By registerLink = By.linkText("Register");

    public void goToRegisterPage() {
        driver.findElement(registerLink).click();
    }
}
